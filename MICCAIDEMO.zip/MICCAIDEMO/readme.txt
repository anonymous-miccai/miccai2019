Dear reviewers,

please find examples of our physical simulation results running in realtime detailed in our manuscript we have provided 2 of 103 sets of comparison simulations. 

The first directory is the mean difference between AR vessel placement simulations that use a traditional method vs our MRE data driven method
MEAN/ATLAS/*.mp4 is the traditional AR technique (no patient specific stiffness).
MEAN/MRE/*.mp is our data driven technique

The second directory is an example the first standard deviation of difference between our MRE method and a traditional method

SD1/ATLAS/*.mp4 is the traditional technique
SD1/MRE/*.mp4 is our data driven technique

we provide examples of the simulatior files for your review also
